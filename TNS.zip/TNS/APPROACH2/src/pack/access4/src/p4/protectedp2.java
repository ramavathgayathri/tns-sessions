package p4;

public class protectedp2 {
	protected void display4()
	{
		System.out.println("protected access modifier");
	}

}
