package p2;

public class Myclass2 {
	public void display()
	{
	System.out.println("public acess modifier");
	}
	public static void main(String[] args) {
		Myclass2 obj=new Myclass2();
		obj.display();

		// TODO Auto-generated method stub

	}

}
