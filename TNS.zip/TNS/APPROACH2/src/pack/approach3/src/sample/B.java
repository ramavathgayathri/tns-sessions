package sample;

public class B {
	public static void main(String args[])
	{
		int c=20;
		System.out.println(c);
		A obj1=new A();
		System.out.println(obj1.a);
		System.out.println(A.b);
		obj1.display();
		A.display1();
	}

}
