/**
 * 
 */
/**
 * 
 */
module SAMPLE1 {
}